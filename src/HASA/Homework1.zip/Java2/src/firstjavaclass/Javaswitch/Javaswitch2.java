package firstjavaclass.Javaswitch;

public class Javaswitch2 {

    public static void main(String[] args) {


        int Studentname = 4;
        switch (Studentname) {

            case 1:
                System.out.println("Divyesh savaliya");
                System.out.println("hendsome");
                break;
            case 2:
                System.out.println("amisha kanani");
                System.out.println("bhoot");
                break;
            case 3:
                System.out.println("hetal desai");
                System.out.println("vaghri");
                break;
            case 4:
                System.out.println("jenish kanani");
                System.out.println("angry man");
                break;
            case 5:
                System.out.println("ayush kikani");
                System.out.println("jadiyo");
                break;
            case 6:
                System.out.println("om patel");
                System.out.println("bathiyo");
                break;


        }
    }
}
