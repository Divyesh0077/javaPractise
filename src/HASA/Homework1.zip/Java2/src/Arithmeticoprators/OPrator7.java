package Arithmeticoprators;

public class OPrator7 {

    public static void main(String[] args) {
        int x=6;
        x ^=4;
        System.out.println(x);
    }
}
