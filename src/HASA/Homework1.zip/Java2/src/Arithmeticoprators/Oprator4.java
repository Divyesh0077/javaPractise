package Arithmeticoprators;

public class Oprator4 {

    public static void main(String[] args) {
        int x =7;
        x /=7;
        System.out.println(x);
    }
}
