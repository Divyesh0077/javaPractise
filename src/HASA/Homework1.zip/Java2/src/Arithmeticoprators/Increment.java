package Arithmeticoprators;

public class Increment {

    public static void main(String[] args) {
        int x = 6;
        ++x;
        System.out.println(x);
    }

}
