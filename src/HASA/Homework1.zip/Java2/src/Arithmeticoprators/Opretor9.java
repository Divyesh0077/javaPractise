package Arithmeticoprators;

public class Opretor9 {
    public static void main(String[] args) {

        int x = 9;
        x <<=8;
        System.out.println(x);
    }
}
