package Arithmeticoprators;

public class Opretor3 {

    public static void main(String[] args) {
        int x =6;
        x *=5;
        System.out.println(x);
    }
}
