package Arithmeticoprators;

public class Oprator5 {

    public static void main(String[] args) {

        int x = 12;
        x %=8;
        System.out.println(x);
    }
}
