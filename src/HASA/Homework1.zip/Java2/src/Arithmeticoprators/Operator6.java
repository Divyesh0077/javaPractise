package Arithmeticoprators;

public class Operator6 {

    public static void main(String[] args) {

        int x=34;
        x &=45;
        System.out.println(x);
    }
}
