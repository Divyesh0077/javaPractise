package divyesh;

import com.sun.org.apache.xpath.internal.objects.XString;

public class Prectice {


    public static void main(String[] args) {
        String myname="divyeshfgffhghnhg";
        int stringLeanght = myname.length();

        System.out.println(myname);
        System.out.println(stringLeanght);
        System.out.println(myname.length());


    }
}
