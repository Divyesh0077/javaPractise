package divyesh;

public class Address {

    public static void main(String[] args) {


        System.out.println("108 sudbury court road");
        System.out.println("HA13SQ");

    }
}
