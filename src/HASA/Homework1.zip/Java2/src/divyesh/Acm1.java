package divyesh;

public class Acm1 {
    int i = 115;
    private  byte Y = 30;
    protected float d = 65;
    private String india;

    public static void main(String[] args) {
        float b = 11.2f;
        int c =  220;

        Acm1 india = new Acm1();
        System.out.println((india.i)+b);
        System.out.println((india.Y)*c);
        System.out.println((india.d)-b);
    }
}
