package Dowhile;

public class Ifandelse {

    public static void main(String[] args) {
        int age = 15;

        if (age <=15) {
            System.out.println("child");
            } else if (age<20)
                System.out.println("young");
        else if (age<25)
            System.out.println("healthy man");
        else if (age<50)
            System.out.println("retired citizen");
        else {
            System.out.println("senior citizen");
        }
            }

        }



