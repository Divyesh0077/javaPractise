package Forloop;

public class Forloop2 {

    public static void addforloop2(){
        for (int i = 0; i <= 10; i = i + 3) {
            System.out.println(i);
        }
    }

    public static void main(String[] args) {
        addforloop2();
    }
}






