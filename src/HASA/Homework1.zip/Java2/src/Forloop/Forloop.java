package Forloop;

public class Forloop {

        public static void addforloop(){

            for (int a=1;a<50;a++){
                System.out.println();
            }
        }

    public static void main(String[] args) {
        addforloop();
    }

}
