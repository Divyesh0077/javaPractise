package Modulus;

public class Modulus {
    public static void main(String[] args) {
        int x=6;
        int y=8;
        System.out.println(x % y);
        int a=6;
        x++;
        --y;

        System.out.println(a);
        System.out.println(y);
        System.out.println(a);
        System.out.println(--y);
    }

}
