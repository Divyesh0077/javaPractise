package Datatype;

public class DataDefolt {
    static byte c = 4 ;

    static double size = 5.4;
    static short number ;


    public static void main(String[] args) {
        System.out.println(c);
        System.out.println(size);
        System.out.println(number);

    }

}
