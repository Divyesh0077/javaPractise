package Datatype;

import Datatype.Datatype;

public class Datatype2 {

    static int x = 10;
    static float size  = 25.577f;
    // decimal
    static long number = 12345;
    static boolean todaysunday = false;
    // true & false
    static byte y = 5;
    // number only
    static double z = 5685.58454;

    public static void main(String[] args) {
        Datatype Prectice = new Datatype();

        System.out.println(x);
        System.out.println(size);
        System.out.println(todaysunday);
        System.out.println(y);
        System.out.println(z);
    }

}
