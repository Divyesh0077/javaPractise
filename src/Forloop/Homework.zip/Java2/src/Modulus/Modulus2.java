package Modulus;

public class Modulus2 {

    public static void main(String[] args) {
        int x=6;

        System.out.println(x>6 || x<5);
        //if i put ! result is revers
    }
}
