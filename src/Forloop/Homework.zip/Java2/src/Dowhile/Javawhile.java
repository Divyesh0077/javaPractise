package Dowhile;

public class Javawhile {

    public static void main(String[] args) {
        int x = 0;
        while (x < 10) {
            System.out.println(x);
            System.out.println(15-x);
            ++x;

        }
    
}
}

