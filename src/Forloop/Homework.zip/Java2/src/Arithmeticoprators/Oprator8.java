package Arithmeticoprators;

public class Oprator8 {
    public static void main(String[] args) {

        int x =8;
        x >>= 6;
        System.out.println(x);
    }
}
