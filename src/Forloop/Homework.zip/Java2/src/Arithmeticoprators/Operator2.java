package Arithmeticoprators;

public class Operator2 {
    public static void main(String[] args) {
        int x=4;
        x -=5;
        System.out.println(x);
    }
}
