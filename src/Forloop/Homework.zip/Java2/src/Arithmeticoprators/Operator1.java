package Arithmeticoprators;

public class Operator1 {

    public static void main(String[] args) {

        int x=65;
        x +=6;
        System.out.println(x);
    }

}
