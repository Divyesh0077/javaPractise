package Arithmeticoprators;

public class Division {
    public static void main(String[] args) {
        int x = 15;
        int y = 3;
        System.out.println(x/y);

    }
}
