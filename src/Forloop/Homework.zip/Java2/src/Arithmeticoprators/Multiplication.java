package Arithmeticoprators;

public class Multiplication {


    public static void main(String[] args) {
        int x = 45;
        int y = 54;

        System.out.println(x*y);
    }
}
