package Arithmeticoprators;

public class Decrement {


    public static void main(String[] args) {
        int x = 65;
        --x;
        System.out.println(x);
    }
}
