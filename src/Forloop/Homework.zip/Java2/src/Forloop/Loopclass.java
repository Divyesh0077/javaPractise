package Forloop;

public class Loopclass {

    public static void add(){

        int x=10;
        while (x>5){
            System.out.println(10+x);

        --x;
        }
    }

    public static void main(String[] args) {
        add();
    }
}
