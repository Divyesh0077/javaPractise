package firstjavaclass;

public class Work {
    static int c = 2;
    static int d = 0;


    public static void main(String[] args) {
        int h,i,j,b;


        h = 1;
        i = 2;
        j = 3;


        System.out.println("the value:3");


        b = h + i + j;
        System.out.println("sum of:"+b);

        System.out.println(d+c);
        // sum value


        System.out.println("subtraction:"+(h-i-j));
        // subtraction value

        System.out.println("equal value:"+(j=i));
        // equal value

        System.out.println("The multiplication of:"+h*i*j);
        System.out.println(h*i*j);
        // multiplication value


        System.out.println("address 108 sudbury court road");
        System.out.println("town - Harrow");
        System.out.println("HA13SQ");
        System.out.println("i love india");
        // print address






        System.out.println(h+c);







    }
}
 

 
