package divyesh;

public class Methodtype {
    public static void main(String[] args) {
        int sum1 = 2 + 5;
        System.out.println(sum1);
        add(1,2);
        multi(3,4);
        Acm1 gujrat = new Acm1();
        int a = 15;
        System.out.println((gujrat.i)-a);
        //  modifier
    }


    public static void multi(int a, int b){
        int c = a*b;
        System.out.println(c);
    }


    public static int add(int a, int b) {
        int sum1 = a + b;
        System.out.println(sum1);
        return a + b;


    }


    }


