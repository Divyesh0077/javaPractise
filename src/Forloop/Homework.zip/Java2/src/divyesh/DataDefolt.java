package divyesh;

public class DataDefolt {
    static byte c ;

    static double size ;
    static short number ;


    public static void main(String[] args) {
        System.out.println(c);
        System.out.println(size);
        System.out.println(number);

    }

}
