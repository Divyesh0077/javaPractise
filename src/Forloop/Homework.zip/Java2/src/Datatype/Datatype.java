package Datatype;

public class Datatype {

    public int a;

    public static void main(String[] args) {



    byte houseNumber = 3;

    short number = 23;
    int name = 123;
    long nme = 456789123;
    char size = 4;
    double weight = 5.9999;
    float hight = 15.9f;

    boolean indiaisoneoftherechestcountry = true;
    //depend on size and data
    // type of decleration

        System.out.println(houseNumber);
        System.out.println(weight);
        System.out.println(hight);
        System.out.println(indiaisoneoftherechestcountry);

}

}
